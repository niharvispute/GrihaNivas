const router = require('express').Router();

router.use('/auth',         require('./auth'));
router.use('/builders',     require('./builders'));
router.use('/admin/builders', require('./adminBuilders'));
router.use('/properties',   require('./properties'));
router.use('/projects',     require('./projects'));
router.use('/leads',        require('./leads'));
router.use('/property-submissions', require('./propertySubmissions'));
router.use('/users',        require('./users'));
router.use('/blogs',        require('./blogs'));
router.use('/testimonials', require('./testimonials'));
router.use('/banners',      require('./banners'));
router.use('/stamp-duty',   require('./stampDuty'));
router.use('/offers',       require('./offers'));
router.use('/calculators',  require('./calculators'));
router.use('/contact',      require('./contact'));
router.use('/dashboard',    require('./dashboard'));
router.use('/system',       require('./system'));

module.exports = router;
